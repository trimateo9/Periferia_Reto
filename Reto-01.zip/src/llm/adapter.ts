export type ChatMessage = { role:'system'|'user'|'assistant'|'tool'; content:string; tool_call_id?:string; tool_calls?:Array<{id:string;type:'function';function:{name:string;arguments:string}}> };
export type LlmResponse = { content:string|null; toolCalls:Array<{id:string;name:string;arguments:string}> };
export interface LlmAdapter { enviar(mensajes:ChatMessage[],herramientas:unknown[]):Promise<LlmResponse>; provider:string; model:string; }
export class OpenAICompatibleAdapter implements LlmAdapter {
 provider='openai-compatible';
 constructor(public baseUrl:string,private apiKey:string,public model:string,private timeoutMs=30000){}
 async enviar(mensajes:ChatMessage[],herramientas:unknown[]):Promise<LlmResponse>{
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),this.timeoutMs);
  try { const response=await fetch(`${this.baseUrl.replace(/\/$/,'')}/chat/completions`,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${this.apiKey}`},body:JSON.stringify({model:this.model,messages:mensajes,tools:herramientas,tool_choice:'auto',temperature:0}),signal:controller.signal}); if(!response.ok) throw new Error(`Proveedor LLM respondió HTTP ${response.status}`); const body=await response.json() as any; const msg=body.choices?.[0]?.message; if(!msg) throw new Error('Respuesta inválida del proveedor LLM'); return {content:typeof msg.content==='string'?msg.content:null,toolCalls:(msg.tool_calls??[]).map((t:any)=>({id:t.id,name:t.function.name,arguments:t.function.arguments}))}; } catch(e){ if(e instanceof Error && e.name==='AbortError') throw new Error('Tiempo de espera agotado al consultar el modelo'); throw e; } finally {clearTimeout(timer);} }
}
export function createAdapter():LlmAdapter|null { const key=process.env.LLM_API_KEY; if(!key) return null; return new OpenAICompatibleAdapter(process.env.LLM_BASE_URL??'https://api.openai.com/v1',key,process.env.LLM_MODEL??'gpt-4o-mini'); }

# Conocimiento del proceso: registro como proveedor

## Propósito
Preparar formularios de registro a partir de solicitudes y del repositorio maestro ficticio. El sistema no firma, no envía correos y no ingresa a portales reales.

## Estados de mapeo
- `lleno`: existe una fuente concreta en `repositorio/maestro.json`; registrar ruta de origen.
- `faltante`: no hay valor en el maestro. Nunca inferir ni inventar valores.
- `requiere_confirmacion`: equivalencia ambigua, confianza inferior a 0.8 o identificador tributario extranjero.

## Reglas
- CO usa NIT; EC/PE/PA usan RUC; HN usa RTN. El maestro solo tiene NIT colombiano: mapearlo a identificadores extranjeros exige confirmación humana y nota `identificador extranjero`.
- Datos bancarios solo se escriben si la plantilla los solicita. Nunca incluir cuentas bancarias en borradores de correo.
- Un soporte exigido ausente o vencido bloquea `listo_para_firma`; campos faltantes se reportan pero no bloquean por sí solos.
- Portal web: no automatizar login ni envío. Generar valores copiable y dejar credenciales y clic final al humano.
- No realizar acciones externas. `proveedor_simular_envio` escribe solo un artefacto local y exige confirmación explícita en el turno inmediatamente anterior.

## Datos
Los fixtures son ficticios y de solo lectura. Toda ruta debe resolverse desde la raíz del proyecto y validarse para evitar traversal.

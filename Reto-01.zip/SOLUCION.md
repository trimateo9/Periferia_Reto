# SOLUCION — Reto 01: Registro como Proveedor

## 1. Problema en una frase
La analista administrativa pierde tiempo transcribiendo información repetida y buscando soportes para registros de proveedores; el agente prepara formularios y un paquete revisable sin tomar decisiones de firma o envío.

## 2. Arquitectura
```mermaid
flowchart LR
  U[Analista administrativa] --> W[Frontend chat: web/]
  W --> API[Express: src/server.ts]
  API --> LOOP[Ciclo agente y sesiones]
  LOOP --> LLM[Adaptador LLM opcional: src/llm/adapter.ts]
  LOOP --> T[Herramientas tipadas con Zod: src/tools/proveedor.ts]
  T --> F[fixtures/reto-01/ solo lectura]
  T --> O[out/ formularios, paquete y logs]
  P[agent/prompt.md] --> LOOP
  K[src/knowledge/registro-proveedor.md] -. conocimiento documentado .-> LOOP
```

- **Comportamiento:** `agent/prompt.md`.
- **Conocimiento del proceso:** `src/knowledge/registro-proveedor.md`.
- **Ejecución:** `src/tools/proveedor.ts`; las mismas herramientas se importan desde `demo.ts`.
- **Interfaz:** HTML/CSS/JS sin framework para reducir el arranque.
- **Persistencia:** sesiones en memoria; artefactos y logs en `out/`.

## 3. Ciclo del agente y confirmación
El endpoint `POST /api/chat` agrega el mensaje al historial y, cuando existe configuración LLM, llama al adaptador con herramientas declaradas. Las tool calls se validan con Zod, se ejecutan y sus resultados vuelven al modelo. Hay un límite configurable (`MAX_AGENT_ITERATIONS`, por defecto 25), mensajes limitados por sesión (`MAX_SESSION_MESSAGES`) y timeout del proveedor (30 s). Sin clave, el modo determinista invoca directamente las herramientas y ofrece el mismo flujo de procesamiento básico.

Las herramientas nunca deben lanzar excepciones al ciclo: serializan `{ok:true,data}` o `{ok:false,error}`. El frontend muestra argumentos y resultado resumido de cada llamada. La acción final es siempre simulada y requiere confirmación explícita; no existe envío externo.

## 4. Elección del modelo y costo
El adaptador es OpenAI-compatible y configurable mediante `LLM_BASE_URL`, `LLM_API_KEY` y `LLM_MODEL`. Valor sugerido para una demo: `gpt-4o-mini`; el usuario puede seleccionar otro endpoint compatible. No se fija un costo por caso porque depende de tarifas vigentes, tokens de solicitud, plantilla, resultados de herramientas y longitud de conversación. Para calcularlo antes de producción: `(tokens_entrada × tarifa_entrada + tokens_salida × tarifa_salida) / 1.000.000`, usando tarifas vigentes del proveedor. La demo sin modelo no incurre en costo de LLM.

## 5. Diseño de portales web
En una fase futura se podría usar automatización de navegador controlada (Playwright/RPA) con una sesión supervisada. Límites: CAPTCHA, MFA, cambios de layout, expiración de sesión y términos de uso del portal. Las credenciales deben ingresarlas humanos en un gestor de secretos o formulario seguro efímero; nunca se guardan en el repo, prompt, fixtures o logs. El agente puede preparar los campos y una lista de comprobación; el humano inicia sesión, valida los datos y hace clic en “Enviar”. En esta entrega el portal solo genera `valores-portal.md`.

## 6. Decisiones y trade-offs
1. **Frontend sin framework:** menos dependencias y arranque sencillo; alternativa descartada: React, que mejora escalabilidad de UI pero añade configuración de build.
2. **Adaptador OpenAI-compatible propio:** permite cambiar endpoint/modelo sin modificar el ciclo; alternativa descartada: SDK específico de un proveedor, que acopla herramientas y tipos.
3. **Modo determinista sin LLM:** demo reproducible sin secretos ni gasto; alternativa descartada: requerir un modelo para toda operación, que dificulta la evaluación y no cumple `demo.ts` sin clave.
4. **PDF generado desde estructura:** simple y trazable; alternativa descartada: edición de AcroForm, no necesaria según P1.
5. **Sin persistencia DB:** sesiones en memoria y archivos bajo `out/`; alternativa descartada: base de datos, fuera del alcance del PRD.

## 7. Supuestos
- Los JSON adjuntos son la fuente de verdad y no se modifican.
- La ausencia de plantillas binarias se resuelve generando XLSX nuevo en las hojas/celdas declaradas.
- Para portal sin plantilla estructurada, los campos copiabes se derivan del conjunto de campos comunes en el glosario y del caso de Panamá.
- Las fechas de vencimiento se evalúan contra la fecha local de ejecución en formato ISO (YYYY-MM-DD).

## 8. Cobertura de historias de usuario
| Historia | Estado | Alcance / pendiente para producción |
|---|---|---|
| HU-1 Leer solicitud | Hecho | Extrae solicitud, formato, campos y soportes desde fixtures; etiquetas ambiguas se elevan a confirmación mediante el mapeo. |
| HU-2 Mapear campos | Hecho | Glosario y maestro; estados lleno/faltante/confirmación; mejorar pruebas de confianza semántica en producción. |
| HU-3 Generar formulario | Hecho en alcance de reto | XLSX por celdas, PDF generado y Markdown para portal. No hay plantillas binarias originales. |
| HU-4 Paquete para firma | Hecho | Copia soportes presentes, checklist, borrador sin datos bancarios; bloquea por soportes vencidos/ausentes. Validación legal humana pendiente. |
| HU-5 Manejo de errores | Parcial | Errores serializados y mensajes claros; ampliar matriz de corrupción de archivos y pruebas de estrés. |
| Ciclo de agente y UI | Hecho base | Chat, sesiones en memoria, eventos de herramientas; falta despliegue público y prueba manual de proveedor LLM real. |
| `demo.ts` sin modelo | Hecho base | Ejecuta las herramientas de todos los casos; requiere correr `npm install` antes. |

## 9. Uso de IA
Se utilizó ChatGPT (GPT-6) para interpretar el PRD, proponer la arquitectura, redactar el código inicial, documentación y pruebas. Las decisiones se verifican contra los criterios del PRD; no se acepta que el modelo invente valores de negocio. No se usó IA para generar datos reales; los fixtures proporcionados son ficticios. La persona que entrega debe revisar y poder explicar cada archivo y línea, según el requisito del reto.

## 10. Riesgos de producción y mitigaciones
- **Dato maestro desactualizado:** definir dueño de datos, fecha de actualización y aprobación antes de uso externo.
- **Mapeo incorrecto:** conservar ruta de origen, umbral de confianza y revisión humana de identificadores tributarios extranjeros.
- **Exposición de datos sensibles:** mínimos privilegios, cifrado, redacción de logs y gestión segura de secretos.
- **Prompt injection en correos/plantillas:** tratar fixtures como datos, nunca como instrucciones; listas permitidas de herramientas.
- **Soporte vencido:** bloquear firma y mostrar fecha y tipo en checklist.
- **Uso indebido de la clave LLM:** límites de iteraciones/tokens, timeout, monitoreo y rate limiting del endpoint público.
- **Confirmación ambigua:** token de confirmación ligado a sesión/caso, vencimiento y confirmación separada para acciones externas reales.
- **Disponibilidad:** persistencia de sesiones y observabilidad antes de producción.

## Seguridad crítica
Los fixtures y los artefactos de esta solución contienen únicamente datos ficticios. Nunca incluir claves, contraseñas de portales ni datos bancarios en el borrador de correo. La herramienta de envío solo crea un archivo de simulación y no realiza llamadas externas.

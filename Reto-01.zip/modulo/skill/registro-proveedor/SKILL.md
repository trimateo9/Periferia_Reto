---
name: registro-proveedor
description: Conocimiento del proceso de registro de proveedor, mapeo de campos y control de soportes.
---
# Registro como proveedor

- Leer solicitud y plantilla antes de mapear.
- Estados: `lleno`, `faltante`, `requiere_confirmacion`.
- Nunca inventar datos. El maestro ficticio es la única fuente de valores.
- CO: NIT; EC/PE/PA: RUC; HN: RTN. El NIT colombiano usado en un país extranjero requiere confirmación.
- Datos bancarios solo en campos expresamente solicitados; nunca en el borrador de correo.
- Soportes ausentes o vencidos bloquean `listo_para_firma`.
- El agente no firma, no envía y no automatiza el login de portales.

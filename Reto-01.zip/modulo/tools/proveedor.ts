// La implementación única y canónica está en ../src/tools/proveedor.ts del proyecto raíz.
// Este punto de entrada evita duplicar lógica y mantiene iguales las reglas de negocio.
export { tools, executeTool, leer_solicitud, mapear_campos, generar_formulario, armar_paquete, simular_envio } from '../../src/tools/proveedor.js';

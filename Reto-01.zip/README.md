# Agente conversacional — Registro como Proveedor

Solución del Reto técnico 01. Preparación de formularios y paquetes para firma usando exclusivamente los fixtures ficticios entregados. La firma, el envío real y el acceso a portales permanecen bajo control humano.

## Requisitos
- Node.js 20+ (probado como objetivo de runtime; Node 22 recomendado).
- npm.
- Opcional: una API compatible con OpenAI Chat Completions para activar el ciclo LLM.

## Arranque local
```bash
npm install
cp .env.example .env
npm run dev
```
Abre `http://localhost:3000`. Sin `LLM_API_KEY`, el chat utiliza un flujo determinista que procesa los casos y no requiere proveedor externo.

## Demo sin modelo
```bash
npm run demo
```
Limpia `out/`, ejecuta las herramientas directamente para todos los casos y muestra conteos, artefactos y estado del paquete. No necesita `.env` ni clave LLM.

## Pruebas y tipos
```bash
npm test
npm run typecheck
```

## Configuración LLM (opcional)
En `.env` del backend, configura `LLM_BASE_URL`, `LLM_API_KEY` y `LLM_MODEL`. Por defecto el adaptador apunta a `https://api.openai.com/v1` y `gpt-4o-mini`. El secreto solo se lee en backend. Nunca lo pongas en el frontend, fixtures, logs ni repositorio. Cualquier endpoint compatible con Chat Completions puede configurarse mediante `LLM_BASE_URL`.

## API
- `GET /api/health`: estado, proveedor y modelo sin exponer la clave.
- `POST /api/chat`: JSON `{ "sessionId": "opcional", "message": "Procesa el caso ec-corp-andina" }` → `{ sessionId, reply, toolCalls, needsConfirmation, provider }`.
- `GET /api/sessions/:id`: historial y eventos de herramienta de la sesión en memoria.

## Casos
- `co-industrias-delta`: Excel.
- `ec-corp-andina`: PDF.
- `hn-agroexport-sula`: Excel.
- `pa-logistica-istmo`: portal; genera valores copiabes en Markdown y no abre el portal.

Los fixtures originales se mantienen bajo `fixtures/reto-01/` sin modificaciones. Los artefactos y logs se generan en `out/`.

## Confirmación humana
El agente pregunta antes de proponer el envío simulado. Solo una confirmación explícita en el turno inmediatamente siguiente puede crear `out/<caso>/ENVIO-SIMULADO.md`. Este archivo documenta una simulación local: no se envía correo ni se realiza acción externa. Un soporte ausente o vencido bloquea `listo_para_firma`.

## Límites conocidos
- No integra correo, SharePoint, firma electrónica ni portales reales.
- Las sesiones viven en memoria y se pierden al reiniciar.
- El PDF se genera desde los campos estructurados; no es un AcroForm rellenado.
- El Excel se construye según hojas/celdas del fixture; el ZIP no contiene plantillas binarias originales, por lo que se produce un libro nuevo con etiquetas y valores en las coordenadas indicadas.
- El despliegue público no está incluido; debe desplegarse en un host Node y configurarse el proveedor si se quiere usar LLM en una URL pública.
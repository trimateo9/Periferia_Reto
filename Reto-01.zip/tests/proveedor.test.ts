import { describe,it,expect,beforeEach } from 'vitest'; import fs from 'node:fs/promises'; import path from 'node:path'; import { executeTool,type ToolContext } from '../src/tools/proveedor.js';
const root=process.cwd();const ctx:ToolContext={directory:root,sessionId:'test'};
async function run(name:string,args:unknown){return JSON.parse(await executeTool(name,args,ctx));}
beforeEach(async()=>{await fs.rm(path.join(root,'out'),{recursive:true,force:true});});
describe('herramientas proveedor',()=>{
 it('lee los cuatro casos y respeta su formato',async()=>{for(const [caso,formato] of [['co-industrias-delta','xlsx'],['ec-corp-andina','pdf'],['hn-agroexport-sula','xlsx'],['pa-logistica-istmo','portal']]){const r=await run('proveedor_leer_solicitud',{caso});expect(r.ok).toBe(true);expect(r.data.formato).toBe(formato);}});
 it('no inventa valores cuando el caso no existe',async()=>{const r=await run('proveedor_leer_solicitud',{caso:'caso-inexistente'});expect(r.ok).toBe(false);});
 it('genera formulario xlsx',async()=>{const r=await run('proveedor_leer_solicitud',{caso:'co-industrias-delta'});const m=await run('proveedor_mapear_campos',{caso:'co-industrias-delta',campos:r.data.campos});const g=await run('proveedor_generar_formulario',{caso:'co-industrias-delta',mapeo:m.data});expect(g.ok).toBe(true);expect(await fs.stat(path.join(root,g.data.ruta))).toBeTruthy();});
 it('exige confirmación explícita para simular envío',async()=>{const no=await run('proveedor_simular_envio',{caso:'ec-corp-andina',confirmado:false});expect(no.ok).toBe(false);expect(no.error).toContain('confirmación');const yes=await run('proveedor_simular_envio',{caso:'ec-corp-andina',confirmado:true});expect(yes.ok).toBe(true);expect(await fs.readFile(path.join(root,yes.data.ruta),'utf8')).toContain('No se envió ningún correo');});
 it('genera PDF',async()=>{const r=await run('proveedor_leer_solicitud',{caso:'ec-corp-andina'});const m=await run('proveedor_mapear_campos',{caso:'ec-corp-andina',campos:r.data.campos});const g=await run('proveedor_generar_formulario',{caso:'ec-corp-andina',mapeo:m.data});expect(g.ok).toBe(true);expect(g.data.formato).toBe('pdf');});
});
